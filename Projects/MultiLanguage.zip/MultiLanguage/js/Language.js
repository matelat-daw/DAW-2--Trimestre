class Language
{
    constructor (title, subtitle, menu_index_first, menu_index_second, menu_login_first, menu_login_second, footer_first, footer_second)
    {
        this.title = title;
        this.subtitle = subtitle;
        this.menu_index_first = menu_index_first;
        this.menu_index_second = menu_index_second;
        this.menu_login_first = menu_login_first;
        this.menu_login_second = menu_login_second;
        this.footer_first = footer_first;
        this.footer_second = footer_second;
    }
}