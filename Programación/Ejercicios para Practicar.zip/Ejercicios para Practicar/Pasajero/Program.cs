﻿public class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Pasajeros al Tren");
        Pasajero[] pasajero = new Pasajero[40];

        for (int i = 0; i < 40; i++)
        {
            pasajero[i] = new($"Viajero-{i}");
        }

        VagonPasajeros vagon = new (40);

        for (int i = 0; i < 40; i++)
        {
            vagon.Subir(pasajero[i]);
        }

        Pasajero viajero = vagon.Bajar("Viajero-20");
        if (viajero != null)
        {
            Console.WriteLine($"El Pasajero: {viajero.GetNombre()} Ha Bajado del Tren.");
        }
        else
        {
            Console.WriteLine("El Nombre Recibido no Corresponde a Ningún Pasajero.");
        }
    }
}