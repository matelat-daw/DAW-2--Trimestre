﻿public class VagonPasajeros
{
    public Pasajero[] pasajeros;
    public static int indice = 0;

    public VagonPasajeros(int capacidad)
    {
        this.pasajeros = new Pasajero[capacidad];
    }

    public void Subir(Pasajero pasajero)
    {
        pasajeros[indice++] = pasajero;
    }

    public Pasajero Bajar(string nombre)
    {
        Pasajero pasajero = null;

        for (int i = 0; i < indice; i++)
        {
            if (pasajeros[i].GetNombre() == nombre)
            {
                pasajero = pasajeros[i];
                pasajeros[i] = null;
            }
        }
        return pasajero;
    }
}