﻿public class Tranvia
{
    private VagonPasajeros[] vagones;
    public static int indice = 0;

    public Tranvia()
    {
        this.vagones = new VagonPasajeros[4];
        for (int i = 0; i < vagones.Length; i++)
        {
            vagones[i] = new(40);
        }
    }

    public Tranvia(int numVagones)
    {
        this.vagones = new VagonPasajeros[numVagones];
        for (int i = 0; i < vagones.Length; i++)
        {
            vagones[i] = new(40);
        }
    }

    public Pasajero Bajar(string nombre, int numVagon)
    {
        int i;
        Pasajero pasajero = null;

        for (i = 0; i < 40; i++)
        {
            if (vagones[numVagon].pasajeros[i].GetNombre() == nombre)
            {
                pasajero = new(nombre);
                vagones[numVagon].pasajeros[i] = null;
            }
        }
        return pasajero;
    }

    public int Subir(Pasajero pasajero, int vagon)
    {
        int i;
        int resultado = 0;

        for (i = vagon; i < vagones.Length; i++)
        {
            if (vagones[i].pasajeros[i] == null)
            {
                vagones[i].pasajeros[i] = pasajero;
                resultado = i;
                i = vagones.Length;
            }
        }
        if (vagon != 0)
        {
            for (i = 0; i < vagon; i++)
            {
                if (vagones[i].pasajeros[i] == null)
                {
                    vagones[i].pasajeros[i] = pasajero;
                    resultado = i;
                    i = vagones.Length;
                }
            }
        }
        if (i > vagones.Length)
        {
            throw new Exception("El Tren Va Lleno, no Cabe ni un Alma.");
        }
        return resultado;
    }
}