﻿public class Pasajero
{
    private string nombre;

    public Pasajero(string nombre)
    {
        this.nombre = nombre;
    }

    public string GetNombre() { return nombre; }
}