﻿public static class Figuras // La Clase Figuras no la Pide, Yo la Usé en la Primera Versión pero no le Gusto. si Quieres te la Envío Como lo Hice Yo.
{
    public static void heart()
    {
        Console.WriteLine("|   **      **     |");
        Console.WriteLine("|  ****    ****    |");
        Console.WriteLine("|  *****  *****    |");
        Console.WriteLine("|    ********      |");
        Console.WriteLine("|      ****        |");
        Console.WriteLine("|       **         |");
        Console.WriteLine("|        *         |");

    }

    public static void pic()
    {
        Console.WriteLine("|      **          |");
        Console.WriteLine("|     ****         |");
        Console.WriteLine("|   ********       |");
        Console.WriteLine("|  **********      |");
        Console.WriteLine("|   ********       |");
        Console.WriteLine("|      **          |");
        Console.WriteLine("|    ******        |");
    }

    public static void diamond()
    {
        Console.WriteLine("|      **          |");
        Console.WriteLine("|     ****         |");
        Console.WriteLine("|   ********       |");
        Console.WriteLine("| ************     |");
        Console.WriteLine("|   ********       |");
        Console.WriteLine("|     ****         |");
        Console.WriteLine("|      **          |");
    }

    public static void clover()
    {
        Console.WriteLine("|   **       **    |");
        Console.WriteLine("|  ****     ****   |");
        Console.WriteLine("|  ***** * *****   |");
        Console.WriteLine("|     *******      |");
        Console.WriteLine("|  ***** * *****   |");
        Console.WriteLine("|  ****  *  ****   |");
        Console.WriteLine("|   **    *  **    |");
    }
}