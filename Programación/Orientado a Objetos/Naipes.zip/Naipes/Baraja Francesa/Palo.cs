﻿public enum Palo
{
    Pica,
    Trebol,
    Diamante,
    Corazon
}