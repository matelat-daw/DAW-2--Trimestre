﻿public enum Direction // Enumeración de las Direcciones North = Arriba, South = Abajo, etc.
{
    North,
    South,
    East,
    West
}