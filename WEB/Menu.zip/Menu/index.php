<?php
$title = "Testing Menues";
include "includes/header.php";
include "includes/nav.html";
?>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br>
                    <h1>Título - 1</h1>
                </div>
                <div id="view2">
                <br><br>
                <h1>Título - 2</h1>
                </div>
                <div id="view3">
                <br><br>
                <h1>Título - 3</h1>
                </div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<script>screenSize();</script>
<?php
include "includes/footer.html";